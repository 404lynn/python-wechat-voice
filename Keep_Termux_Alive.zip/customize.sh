#!/system/bin/sh
MODDIR=${0%/*}

ui_print "安装中，请稍等..."
sleep 1
ui_print "定时检测Termux是否前台运行,否则自动启动"


sleep 1
ui_print "安装已完成，请重启 ↘"

